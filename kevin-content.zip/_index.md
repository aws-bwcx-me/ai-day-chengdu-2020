+++
title = "首页"
chapter = false
weight = 1
tags = [ "AI", "Machine Learning" ]
+++


# AWS AI Day 成都站 - 2020.11
**********

{{% notice tip %}}
要完成所有的实验，大概需要 1-2 小时。
{{% /notice  %}}

{{% notice info %}}
我们的实验使用的区域是AWS的美国东部 (弗吉尼亚北部)（us-east-1），如果一不小心进入了别的区域，记得在控制台切换回即可。
{{% /notice  %}}


文档和版权信息
**********
更新日期： 2020-11  
 
